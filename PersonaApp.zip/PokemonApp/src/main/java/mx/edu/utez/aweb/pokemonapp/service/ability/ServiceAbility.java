package mx.edu.utez.aweb.pokemonapp.service.ability;

public class ServiceAbility {
}