package mx.edu.utez.aweb.pokemonapp.utils;

import javax.servlet.*;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

@WebFilter(urlPatterns = {"/**"})
public class RequestFilter implements Filter{

    List<String> whiteList = new ArrayList<>();

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        whiteList.add("/");
        whiteList.add("/register-user");
        whiteList.add("/public-home");
        whiteList.add("/signin");
        whiteList.add("/login");
        //Filter.super.init(filterConfig);
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        String action = request.getServletPath();

        if (whiteList.contains(action)){
            filterChain.doFilter(servletRequest,servletResponse);
        }else {
            HttpSession session = request.getSession();
            if (session.getAttribute("user") != null){
                filterChain.doFilter(servletRequest,servletResponse);
            }else {
                response.sendRedirect(request.getContextPath() + "/index.jsp");
            }
        }
    }

    @Override
    public void destroy() {
        Filter.super.destroy();
    }
}